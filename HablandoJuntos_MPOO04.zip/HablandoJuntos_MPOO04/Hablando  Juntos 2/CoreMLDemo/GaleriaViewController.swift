//
//  GaleriaViewController.swift
//  CoreMLDemo
//
//  Created by iMac 2 on 6/5/19.
//  Copyright © 2019 AppCoda. All rights reserved.
//

import UIKit
import CoreML

class GaleriaViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationBarDelegate {
    
    @IBOutlet weak var Galeryimage: UIImageView!
    var model: Manos!
    
    @IBOutlet var prediccion: UIView!
    let imagePicker = UIImagePickerController()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //imagePicker.delegate = self as! UIImagePickerControllerDelegate & UINavigationControllerDelegate
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true)
        
    
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            Galeryimage.image = pickedImage
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    

}
