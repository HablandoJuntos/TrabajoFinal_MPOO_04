//
//  SecondViewController.swift
//  CoreMLDemo
//
//  Created by Macbook on 5/30/19.
//  Copyright © 2019 AppCoda. All rights reserved.
//

import UIKit


class SecondViewController: UIViewController  {
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
        
        
   

}
